# Code Citations

## License: unknown
https://github.com/adam2417/lab_inv/tree/4978a023d33f16b48bb085fce927d8b14819ac30/public/default/dist/js/jspdf_autotable/jspdf.plugin.autotable.src.js

```
(function (global, factory) {
       typeof exports === 'object' && typeof module !== 'undefined' ? factory(require('jspdf')) :
       typeof define === 'function' && define.amd ? define(['
```


## License: MIT
https://github.com/kesiev/stampadia/tree/2e331753c531663965aa3ea9765fc61c6f88d199/js/Seshat-normal.js

```
== 'object' && typeof module !== 'undefined' ? factory(require('jspdf')) :
       typeof define === 'function' && define.amd ? define(['jspdf'], factory) :
       (global = global
```

